class Factorial{
    public static void main(String[] a){        
        System.out.println(new Element().Init());
    }    
}

class Element {
    public boolean Init(){
        int a;
        int b;
        int c;
        int[] d;
        boolean f;
        boolean isTrue;
        boolean isFalse;
        isFalse = false;
        isTrue = true;
        a = 1;
        a = a + 3;
        if(isTrue){

          }
          else{
            while(isTrue){
                a = a + 2;
                while (isFalse){
                    a = a + 1;
                }
            }
        }
        
                 
        return isTrue;
    }
}