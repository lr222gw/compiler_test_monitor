class Factorial{
    public static void main(String[] a){        
    System.out.println(new Element().Test(1, 2));
    }    
}

class Element {
    public int Test(int num, int tum){
        int sum;
        sum = 0;
                
        while(0 < num){
            sum = sum + num;
            num = num - 1;

            // if(num == sum){
            //    num = 2; 
            // }else{
            //    num = 3; 
            // }
                    
        }
                 
        return sum;
    }
}