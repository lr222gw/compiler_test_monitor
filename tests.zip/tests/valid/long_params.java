class Factorial{
    public static void main(String[] a){        
        System.out.println(new Element().Init());
    }    
}

class Element {
    public boolean Init(){
        int a;
        boolean b;
        a = 1 + 1;
        b = 2/4 + 1 * 2 * 3 + 4 -5 -5 * 2 / 3 < 1;
        System.out.println(b);
        if(this.alotOfParams(a,2/4 + 1 * 2 * 3 + 4 -5 -5 * 2 / 3 < 1, b, this.test(10),this.anotherTest(), this.test(this.goodyTest(this.anotherTest())), 123 ,this.somefunc(5, true,true),321))
            a = 2 + 1;
        else
            b = false;
        return (a < 2);
    }
    public boolean alotOfParams(int x, boolean y, boolean z, int a, int f, int g, int gg,  int h,int i){
        System.out.println(y == z);
        return y == z;
    }
    public int somefunc(int yolo, boolean cooleio , boolean four){
        int a;
        a = yolo  * 10;
        System.out.println(a);
        return a;
    }
    public int test(int f){
        f = f + 3;
        System.out.println(f);
        return f;
    }
    public int goodyTest(int f){
        f = f + 23;
        System.out.println(f);
        return f;
    }
    public int anotherTest(){
        System.out.println(1);
        return 1;
    }
}
//class Factorial{
//    public static void main(String[] a){        
//        System.out.println(new Element().Init());
//    }    
//}
//
//class Element {
//    public boolean Init(){
//        int a;
//        boolean b;
//        int c;
//        a = 1 + 1;
//        b = 2/4 + 1 * 2 * 3 + 4 -5 -5 * 2 / 3 < 1;
//        System.out.println(b);
//        if(this.alotOfParams(a,2/4 + 1 * 2 * 3 + 4 -5 -5 * 2 / 3 < 1, b, this.test()))
//            a = 2 + 1;
//        else
//            b = false;
//        return (a < 2);
//    }
//    public boolean alotOfParams(int x, boolean y, boolean z, int a){
//        return y == z;
//    }
//    public int somefunc(int yolo, boolean cooleio , boolean four){
//        int a;
//        return 1;
//    }
//    public int test(){
//        
//        return 1;
//    }
//}