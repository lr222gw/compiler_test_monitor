class Factorial{
   public static void main(String[] a){  
        System.out.println(new Pemis().func());       
   }    
}


class Pemis{
   Element x;//should work
   int a;
   boolean c;
   boolean d;
   int[] e;
   public int func(){//weird medelande på return
       int dunno;
       //e = new int [2];
       //e[1] = 1;
       //e[2] = e[1];//work
       //a = e[3];//yes
       //a = e[a];//yes

       dunno = this.func();
       
        dunno = x.extroll();
       a = e.length;
       //a = e[1].length;
       //x = e.length;

    return 1;
   }
}

class Element {
   int a;
   boolean b;
   Element c;
   extest Pen;
   
   public int extroll(){
       int r;
       boolean p;
       if(!Pen.exbool()){
           r = 0;
       }
       else
       r = 1;

        if (r == 1) 
			if (!Pen.exbool() && 
			    !Pen.exbool() )
			    r = 1 ;
			else if (! (1 < 3) && ! (true))
			    r = 2; 
            else
                r = 4;
		else 
            r = 3;

       return r;




   }
}

class extest{
    public boolean exbool(){

        return true;
    }
}

