class App{
   public static void main(String[] a){  
        System.out.println(new Game().start());       
   }    
}

class Game{
    boolean GameOver;
    GameManager GM;
    int uret;
    public boolean start(){
        GM = new GameManager();
        uret = this.update();
        return true;
    }
    public int update(){
        int p;
        int[] gos;
        if(true){
            while(GameOver){
                p = GM.getflags(2);
                gos = GM.getflags2();
                p = GM.getflags2()[GM.getflags(2)+ 2];
                p = gos[1] + 2;
            }
        }
        else{
            p = p;
        }
        return p;
    }
    public boolean setGameOver(boolean go){
        GameOver = go;
        return true;
    }
}

class GameObjects{
    int xPos;
    int yPos;
    int hp;
    GameManager gm;

    public boolean move(int x, int y){
        xPos = x + xPos;
        yPos = y + yPos;
        return x < y;
    }
    public boolean setGM(GameManager gmP){
        gm = gmP;
        return true;
    }
    
}

class GameManager{
    int[] flags;

    public int getflags(int wf){
        return flags[wf];
    }
    public int[] getflags2(){
        return flags;
    }
}