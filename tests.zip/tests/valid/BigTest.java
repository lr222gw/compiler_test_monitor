class BigTest{
    public static void main(String[] a){
	   // System.out.println(new LS().Start(10));    //Detta är inte lagligt enl. vår BNF?... LS är ej deklaread någonstans... 
	    //System.out.println(123);    //testar ett tillfälligt alternativ...
        System.out.println(new firstClass().fcFunt(1, true, new firstClass()));
    }
}

//a comment
//both var dec and methods
class firstClass{
    int a;
    secondClass b;
    BigClass bb;
    boolean d;

    //long params
    public int fcFunt(int x, boolean y, firstClass c){
        int bobo;
        boolean anka;
        
        anka = b.scFunt(); //Illegal in Interpretor, cant access class member...
        d = bb.a();
        bobo = this.fcFunt(x, false, this);
        if(y)
        System.out.println(this.fcFunt(x, false, this));
        else
            y = true;
        x = x + 1;
        return x;
    }

}

class BigClass{
    int x;
    int y;
    public boolean a(){
        //{
            //wrong another operator level?
            if(x < 3 && y < 3)
                System.out.println(y);
            else
                while(x > 3)
                    x = x - 1;
                    System.out.println(x);
        //}
        //pen[this] = new secondClass().scFunt();
        return x < 3;
    }
}

//only methods
class secondClass{

    //with no params
    public boolean scFunt(){
        System.out.println(true);
        return true;
    }
}

//only var decs
class thirdClass{
    int x;
    int y;
    int xy;
    int a;
    boolean c;
    secondClass sc;
}

//nothing
class forthClass{

}
