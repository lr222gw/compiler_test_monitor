class FacFib {
  public static void main(String[] a){
     System.out.println(new FacFib2().ComputeFac(5));
     
  }
}

class FacFib2 {  

  public int ComputeFac(int num){
    System.out.println( true && true || true && false);//should print true
    //System.out.println( 1 + 1);
    System.out.println( false || true && false || false);//should print true
    System.out.println( true || true && false || false);//should print true
    return num;
  }

}
//(a & b) || (c & d)
//(((a & b) | c) & d)
