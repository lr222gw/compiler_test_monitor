class Factorial{
    public static void main(String[] a){        
        System.out.println(new Animal().Init());
    }    
}

class Animal {
    String name;
    int nrOfLegs;
    boolean alive;
    public boolean Init(){
        return true;
    }
    public boolean move(){
        alive = this.run();
        return true;
    }
    public boolean run(){
        nrOfLegs = 0;
        //Silly comment
        alive =  this.update();
        return true;
    }
    public boolean update(){
        return false;
    }
}

class Person {
    String name;
    int nrOfLegs;
    boolean alive;
    public boolean Init(){        
        return false;
    }
    public boolean move(){
        alive = this.Init();
        return false;
    }
    public boolean run(){
        nrOfLegs = 0;
        //Silly comment
        alive = this.move();
        return false;
    }
}

class Insect {
    String name;
    int nrOfLegs;
    boolean alive;
    public boolean move(){
        alive =  !this.run();
        return true;
    }
    public boolean run(){
        nrOfLegs = 0;
        //Silly comment
        alive = this.move();
        return false;
    }
}
