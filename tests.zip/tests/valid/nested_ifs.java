class Factorial{
    public static void main(String[] a){        
        System.out.println(new Element().Init());
    }    
}

class Element {
    public boolean Init(){
        int a_before;
        int a_after;
        int b_if;
        int b_else;
        int c_if;
        int c_else;
        int d_if;
        int d_else;
        int[] e;
        boolean f;
        
        a_before = 100 + 100;
        if(true){
            b_if = 200 + 200;
            if(false){
                c_if = 300 + 300;
            }
            else{
                c_else = 310 + 310;
            }

            b_if = 210 + 210;
            if(true){ //B3
                c_if = 320 + 320;
            }else{ //B3
                c_else = 330 + 330;
                if(true){
                    d_if = 400 + 400;
                }
                else{
                    d_else = 410 + 410;
                }
                c_else = 340 + 340; //B9 JOin
            }

            b_if = 220 + 220;
            if(true){
                c_if = 12 + 12;
            }else{
                c_else = 13 + 13;
            }

            b_if = 230 + 230;
        }
        else{
            b_else = 240 + 240;
        }
        a_after = 110 + 110;
        
        return true;
    }
}
