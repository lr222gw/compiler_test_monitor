class Factorial{
    public static void main(String[] a){
        System.out.println(new Child().Init());
    }
}

class Child extends Parent {
    public boolean Init(){
        int Age;
        int v_Age;
        v_Age = 1;
        Age = v_Age;
        return true;
    }
}

class Parent {
    public int veryCoolFunc(){        
        return 1;
    }
}
