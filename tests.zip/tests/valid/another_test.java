class Factorial{
    public static void main(String[] a){        
        System.out.println(new Element().Init());
    }    
}

class Element {
    public boolean Init(){
        int a;
        int b;
        int c;
        int[] d;
        boolean f;
        boolean is_false;
        boolean is_true;
        is_true=true;
        is_false=false;
        a = 1;
        a = a + 3;
        while(is_true){
            a = a + 2;
            
            while (is_true){
                a = a + 1;
                 while (is_true){
                    while (is_true){
                        a = a + 1;

                        if(a > 54){
                            is_true = false;
                        }else{
                            is_true = true; 
                        }
                    }
                    a = a + 1;
                }   
            }
        }
                 
        return is_true;
    }
    public int Test(int num){
        int sum;
        sum = 0;
                
        while(0 < num){
            sum = sum + num;
            num = num - 1;

            if(num == sum){
               num = 2; 
            }else{
               num = 3; 
            }
                    
        }
                 
        return sum;
    }
}