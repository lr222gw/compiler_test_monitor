class Factorial{
    public static void main(String[] a){        
        System.out.println(new Element().Init());
    }    
}

class Element {
    public boolean Init(){
        int a_before;
        int a_after;
        int b_if_begin;
        int b_if_end;
        int b_else_begin;
        int b_else_end;
        int b_else;
        int c_if_begin;
        int c_if_end;
        int c_else_begin;
        int c_else_end;
        int d_if_begin_end;
        int d_else_begin_end;
        
        int c_else;
        int d_if;
        int d_else;
        int[] e;
        boolean f;
        
        //BLOCK : root_1
        a_before = 100 + 100;
        if(true){ 
            //BLOCK : TRUE_B0
            b_if_begin = 200 + 200;
            if(false){ 
                //Block:TRUE_B3
                c_if_begin = 300 + 300;   

                if(true){
                    //Block:TRUE_B6
                    d_if_begin_end = 400 + 400;

                }else{
                    //Block:FALSE_B7
                    d_else_begin_end = 400 + 400;
                }

                //Block:JOIN_B_8 
                c_if_end = 300 + 300;
            }
            else{
                //Block:FALSE_B4
                c_else_begin = 300 + 300;
                if(true){
                    //Block:TRUE_B9
                    d_if_begin_end = 400 + 400;
                }else{
                    //Block:FALSE_B10
                    d_else_begin_end = 400 + 400;
                }
                //Block:JOIN_B_11
                c_else_end = 300 + 300;
            }     

            //############
            //MISSING   
            b_if_end = 200 + 200;                   

        }
        else{
            //Block:FALSE_B1
            b_else_begin = 200 - 200;
            if(true){ 

                //Block:TRUE_B12
                c_if_begin =300 - 300;
                if(true){
                    //Block:TRUE_B15
                    d_if_begin_end = 400 - 400;
                }else{
                    //Block:FALSE_B16
                    d_else_begin_end = 400 - 400;      
                }
                //Block:JOIN_B_17
                c_if_end = 300 - 300;
                
            }else{ 
                //Block:FALSE_B13
                c_else_begin = 300 - 300;
                if(true){
                    //Block:TRUE_B18
                    d_if_begin_end = 400 - 400;
                }
                else{
                    //Block:FALSE_B19
                    d_else_begin_end = 400 - 400;
                }
                //Block:JOIN_B_20
                c_else_end = 300 - 300;
            }

            //############
            //MISSING
            b_else_end = 200 - 200;
        }
        //############
        //MISSING
        a_after = 100 - 100;
        
        return true;
    }
}
