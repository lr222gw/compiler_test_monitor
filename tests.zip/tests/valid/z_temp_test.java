class Bar {
	public static void main(String[] a) {
		System.out.println(new Bar1().foo());
	}
}
class FF {
	int bobo;
    public int pemis(){
        int[] myArr;
        int myInt;
        int myInt2;
        int myArrLength;
        myInt2 = 32;        
        myInt = 3 * myInt2 / 42;
        myArr[myInt2] = myInt;
        myArrLength = this.getArr().length + 555;
        return 123;

    }

    public int[] getArr(){
        int[] myArr;
        int myInt;

        myArr[0] = 12;

        return myArr;

    }
}   

class Bar1 {
	public int foo() {
        int aux;
        boolean aux2;		         
        int tem;      
        int tem2;      
        FF myFF;
        
        //tem = myFF.pemis();
        tem = this.ff().pemis();
        tem2 = myFF.pemis();
        aux = 1 + 2 + 3 + 4;
        aux2 = true;
        aux = this.foo2(aux);
        aux = this.foo3(2,5,aux2);
        
		return aux + 3 + 4 * 2;
	}

    public FF ff() {
        FF myFF;
        int iMnew;
        int nrOf;
        int[] iMnew_arr;
        boolean someBS;
        FF iMnew_class;
        iMnew_class = new FF();
        someBS = true;
        
        nrOf = 32 * 3 ; 
        iMnew_arr = new int[nrOf];


		return myFF;
	}

	public int foo2(int p1) {
        boolean something_false;
        boolean testBool;
        something_false = true;
        testBool = !something_false;
        if(!( 3 + 3 == 6 && something_false))
			System.out.println(30);
		else
			System.out.println(20);

		if(p1 < 2)
			System.out.println(10);
		else
			System.out.println(0);
		
		return 1;
	}

	public int foo3(int p1, int p2, boolean p3) {

        int[] arr;
        int someValue;
        someValue = arr[someValue + 2];
		if (p3) {
			System.out.println(1);
		} else {
			System.out.println(0);
		}
		System.out.println(p1);
		System.out.println(p2-p1);
		return 4;
	}
}
