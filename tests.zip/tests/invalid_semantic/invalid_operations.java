class Factorial{
   public static void main(String[] a){  
                 
   }    
}

class classtest{
    int a1;
    int a2;
    boolean b1;
    boolean b2;
    int[] c1;
    int[] c2;
    datatest d1;
    datatest d2;

    public boolean operator_test_not_work(){
        a1 = a1 + b1;//fail b1_: is of wrong type
        a1 = a1 + c1;//fail c1_: is of wrong type
        a1 = a1 + d1;//fail d1_: is of wrong type
        a1 = b1 + b1;//fail b1_: is of wrong type
        a1 = c1 + c1;//fail  c1_: is of wrong type
        a1 = c1 + c1[0];//fail c1_: is of wrong type
        a1 = d1 + d1;//fail d1_: is of wrong type
        a1 = d1 && d1;//fail d1_: is of wrong type //fail a1_ and expression d1_ && d1_  are of different types
        a1 = d1 || d1;//fail 
        a1 = d1 < d1;//fail
        b1 = b1 + b1;//fail
        b1 = b1 + c1;//fail
        b1 = b1 && c1;//fail
        b1 = b1 == d1;//fail
        c1 = c1 + c2;//fail
        c1 = c1 && c2;//fail
        b1 = b1 < b2;//fail
        return true;
    }
    //works
    public boolean operator_test_work(){
        a1 = a1 + a2; 
        a1 = c1[1] + c2[2];
        a1 = d1.get_trash()[2] + a2;//do we actually check this or is it just lucky?
        b1 = b1 && b2;
        b1 = a1 < a2;
        return true;
    }
    public boolean exclemation_test(){

        return true;
    }

}

class datatest{
    int[] trash;
    public int[] get_trash(){
        return trash;
    }
}
