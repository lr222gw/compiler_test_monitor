class Factorial{
   public static void main(String[] a){  
                 
   }    
}


class Pemis{
   Element x;//should work
   int a;
   boolean c;
   boolean d;
   int[] e;
   public int func(){//weird medelande på return
        int[] pung;
        x = new element();//fail element_ is not a valid Class //fail x_ and expression element_ new  are of different types
        c = new Element();//fail

        a = 2 * e[3*5]; 

        pung[3] = 0;//succ
        a = e.length;//succ
        a = e[1].length;//fail e_ is undefined or wrong
        x = e.length;//fail

        x = new int[1];//fail
        pung = new int[true];//fail
        pung = new int[1];//succ


        return x.InInt();//shouldn't work//weird error message
   }
   public int func2(){
       return x.InInt(1);//should work
   }
}

class Element {
   int a;
   boolean b;
   Element c;
   public int InInt(int x){
       return a;//should work
   }
   public int InInt2(int x){
       return x + 1;//should work
   }
   public Element InClass(){
       return c;//should work
   }
   public boolean InBool(){
       return true;//should work
   }
   public boolean InBool2(){
       return b;//should work
   }
}

// class BigTest{
//     public static void main(String[] a){
// 
//     }
// }

//a comment
//both var dec and methods
//class firstClass{
//    secondClass b;
//
//    //long params
//    public int fcFunt(int x, boolean y, thirdClass c){ //Replaced
//    //public int fcFunt(int x, boolean y, firstClass c){
//        int bobo;
//        boolean anka;
//        
//        anka = b.scFunt();
//        
//        bobo = this.fcFunt(x, false, this, 1);
//        if(y)
//        System.out.println(this.fcFunt(x, false, this));
//        else
//            y = true;
//            x = x + 1;
//        return x;
//    }
//
//}
//
////only methods
//class secondClass{
//
//    //with no params
//    public boolean scFunt(){
//        System.out.println(true);
//        return true;
//    }
//}

